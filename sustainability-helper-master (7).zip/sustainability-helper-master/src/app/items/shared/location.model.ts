export class Location {
    constructor(public place: string,
      public place_lat: number,
      public place_long: number
    ) {}
  }
  