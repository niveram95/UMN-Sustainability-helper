const AppConstants = {
  appName: 'Sustainability Helper',
};

export default AppConstants;
