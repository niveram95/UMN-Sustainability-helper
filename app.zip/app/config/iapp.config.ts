export interface IAppConfig {
  routes: any;
  endpoints: any;
  votesLimit: number;
  topHeroesLimit: number;
  repositoryURL: string;
}
