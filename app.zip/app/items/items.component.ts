import {Component} from '@angular/core';

@Component({
  selector: 'app-heroes',
  templateUrl: './items.component.html'
})

export class HeroesComponent {

  constructor() {

  }
}
